<?php
/**
*
* @package Upload Extensions
* @copyright (c) 2014 - 2015 Igor Lavrov (https://github.com/LavIgor) and John Peskens (http://ForumHulp.com)
* @license http://opensource.org/licenses/gpl-2.0.php FGNU General Public License v2
* @translated Tage Strandell (Webmaster - http://www.vulcanriders-sweden.org)
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_UPLOAD_EXT_TITLE'				=> 'Tilläggsladdaren',
	'ACP_UPLOAD_EXT_CONFIG_TITLE'		=> 'Tilläggsladdaren',
	'ACP_UPLOAD_EXT_DESCRIPTION'		=> 'Installera/uppdatera/ta bort tillägg, hantera deras ZIP-filer och mer utan att använda FTP.',
	'ACP_UPLOAD_EXT_TITLE_EXPLAIN'		=> '"Tilläggsladdaren" ger dig möjlighet att ladda upp tilläggens zip-filer eller ta bort tilläggens mappar från servern.<br />Med det här tillägget kan du installera/uppdatera/ta bort tillägg utan att använda FTP. Om det uppladdade tillägget redan finns, kommer det att uppdateras med de uppladdade filerna.',
	'ACP_UPLOAD_EXT_HELP'				=> '"Tilläggsladdaren": Användarguide',
	'UPLOAD'							=> 'Ladda upp',
	'BROWSE'							=> 'Välj...',
	'EXTENSION_UPLOAD'					=> 'Ladda upp ett tillägg',
	'EXTENSION_UPLOAD_EXPLAIN'			=> 'Här kan du ladda upp ett zippat tilläggspaket som innehåller alla nödvändiga filer för att göra en installation från din lokala hårddisk eller en fjärrserver. “Tilläggsladdaren” kommer att försöka zippa upp filen och förbereda den för inastallation.<br />Välj en fil eller skriv in en länk i fälten nedan.',
	'EXT_UPLOAD_ERROR'					=> 'Tillägget laddades inte upp!',
	'EXT_UPLOAD_INIT_FAIL'				=> 'Det uppstod ett fel när uppladdningen av tillägget startades!',
	'EXT_NOT_WRITABLE'					=> array(
		'error'		=> 'Katalogen "ext/" är inte skrivbar! Det krävs för att “Tilläggsladdaren” ska fungera korrekt.',
		'solution'	=> 'Justera dina behörigheter eller inställningar och försök igen.',
	),
	'EXT_TMP_NOT_WRITABLE'				=> array(
		'error'		=> 'Katalogen "ext/boardtools/upload/tmp/" är inte skrivbar! Det krävs för att “Tilläggsladdaren” ska fungera korrekt.',
		'solution'	=> 'Justera dina behörigheter eller inställningar och försök igen.',
	),
	'EXT_ALLOW_URL_FOPEN_DISABLED'		=> array(
			'error'		=> 'Inställningen "allow_url_fopen" måste vara aktiverad för att hämta information från en extern källa.',
			'solution'	=> 'Säkerställ att "allow_url_fopen" är aktiverad i din php.ini och försök igen.',
	),
	'EXT_OPENSSL_DISABLED'				=> array(
			'error'		=> 'Tillägget "openssl" måste vara aktiverat för att ladda information från en https-källa.',
			'solution'	=> 'Säkerställ att "openssl" är aktiverat i din php.ini och försök igen.',
	),
	'NO_UPLOAD_FILE'					=> array(
		'error'		=> 'Ingen fil har angivits eller så uppstod ett fel under uppladdningen.',
		'solution'	=> 'Säkerställ att du laddar upp rätt zip-fil för tillägget och försök igen.',
	),
	'NOT_AN_EXTENSION'					=> 'Den uppladdade zip-filen är inte ett phpBB-tillägg! Filen sparades inte på servern.',
	'EXT_ACTION_ERROR'					=> 'Den önskade åtgärden kan inte utföras för det valda phpBB-tillägget!<br />OBS! “Tilläggsladdaren” kan endast hanteras med den ordinarie "Tilläggshanteraren".',

	'SOURCE'							=> 'Källa',
	'EXTENSION_UPDATE_NO_LINK'			=> 'Ingen nerladdningslänk har angivits.',
	'EXTENSION_TO_BE_ENABLED'			=> '"Tilläggsladdaren" kommer att deaktiveras under processen och återaktiveras efter uppdateringen.',
	'EXTENSION_UPLOAD_UPDATE'			=> 'Uppdatera tillägget',
	'EXTENSION_UPLOAD_UPDATE_EXPLAIN'	=> '“Tilläggsladdaren” kommer att göra uppladdningen från länken nedan.',

	'EXTENSION_UPLOADED'				=> 'Uppladdningen av tillägget “%s” lyckades.',
	'EXTENSIONS_AVAILABLE'				=> 'Ej installerade tillägg',
	'EXTENSIONS_UPLOADED'				=> 'Ladda upp tillägg',
	'EXTENSIONS_UNAVAILABLE'			=> 'Skadade tillägg',
	'EXTENSIONS_UNAVAILABLE_EXPLAIN'	=> 'Tilläggen listade nedan är uppladdade till ditt forum men av någon anledning är de skadade och därför inte tillgängliga och kan inte aktiveras i forumet. Sök de korrekta filerna och använd verktyget "Tilläggsstädaren" om du vill ta bort filerna till de skadade tilläggen från din server.',
	'EXTENSION_BROKEN'					=> 'Skadade tillägg',
	'EXTENSION_BROKEN_ENABLED'			=> 'Detta skadade tillägg är aktiverat!',
	'EXTENSION_BROKEN_DISABLED'			=> 'Detta skadade tillägg är inaktiverat!',
	'EXTENSION_BROKEN_TITLE'			=> 'Detta tillägg är skadat!',
	'EXTENSION_BROKEN_DETAILS'			=> 'Klicka här för att visa informationen.',
	'EXTENSION_BROKEN_EXPLAIN'			=> '<strong>Viss data för detta tillägg är fortfarande sparad på servern!</strong> Kontrollera varför detta tillägg är skadat! Du kan behöva be tilläggets utvecklare om hjälp och använda FTP för att ändra vissa filer (eller så kan du ladda upp en version med fixar). Därefter kan du använda tillägget igen.<br /><h3>Detta kan du göra:</h3><br /><strong>Uppdatera ett tillägg.</strong><br /><ul><li>Säkerställ att tillägget är inaktiverat (klicka på omställaren om det behövs).</li><li>Undersök om en ny version är tillgänglig. Försök att ladda upp den.</li><li>Om problemet fortfarande inte är löst kan du be tilläggets utvecklare om hjälp.</ul><strong>or</strong><br /><br /><strong>Ta bort det skadade tillägget helt.</strong><br /><ul><li>Säkerställ att tillägget är inaktiverat (klicka på omställaren om det behövs).</li><li>Säkerställ att tilläggets data är raderade (klicka på papperskorgsknappen om det behövs).</li><li>Ta bort tilläggets filer genom att använda verktyget "Tilläggsstädaren".</ul>',

	'EXTENSION_UPLOADED_ENABLE'			=> 'Aktivera det uppladdade tillägget',
	'ACP_UPLOAD_EXT_UNPACK'				=> 'Packa upp tillägget',
	'ACP_UPLOAD_EXT_CONT'				=> 'Innehåll i paketet “%s”',

	'EXT_LIST_DOWNLOAD'					=> 'Ladda ner en fullständig lista',
	'EXT_LIST_DOWNLOAD_ENGLISH'			=> 'Använd Engelska statusnamn',
	'EXT_LIST_DOWNLOAD_GROUP'			=> 'Gruppera efter',
	'EXT_LIST_DOWNLOAD_GROUP_STANDARD'	=> 'uppladdat/skadat',
	'EXT_LIST_DOWNLOAD_GROUP_DISABLED'	=> 'aktiverat/inaktiverat/skadat',
	'EXT_LIST_DOWNLOAD_GROUP_PURGED'	=> 'aktiverat/inaktiverat/avinstallerat/skadat',
	'EXT_LIST_DOWNLOAD_SHOW'			=> 'Inkludera namn',
	'EXT_LIST_DOWNLOAD_SHOW_FULL'		=> 'visa namn och rena namn',
	'EXT_LIST_DOWNLOAD_SHOW_CLEAN'		=> 'bara rena namn',
	'EXT_LIST_DOWNLOAD_SHOW_NAME'		=> 'bara visningsnamn',
	'EXT_LIST_DOWNLOAD_TITLE'			=> 'Komplett lista över uppladdade tillägg',
	'EXT_LIST_DOWNLOAD_FOOTER'			=> 'Genererad av "Tilläggsladdaren"',

	'EXT_ROW_ENABLED'					=> 'aktiverat',
	'EXT_ROW_DISABLED'					=> 'inaktiverat',
	'EXT_ROW_UNINSTALLED'				=> 'avinstallerat',
	'EXT_ROWS_ENABLED'					=> 'Aktiverat:',
	'EXT_ROWS_DISABLED'					=> 'Inaktiverat:',
	'EXT_ROWS_UNINSTALLED'				=> 'Avinstallerat:',
	'EXT_ROWS_UPLOADED'					=> 'Uppladdat:',
	'EXT_ROWS_BROKEN'					=> 'Skadat:',

	'EXTENSION_DELETE'					=> 'Ta bort tillägg',
	'EXTENSION_DELETE_CONFIRM'			=> 'Är det säkert att du vill ta bort tillägget “%s”?',
	'EXTENSIONS_DELETE_CONFIRM'			=> array(
		2	=> 'Är det säkert att du vill ta bort <strong>%1$s</strong> tillägg?',
	),
	'EXT_DELETE_SUCCESS'				=> 'Borttagningen av tillägget lyckades.',
	'EXTS_DELETE_SUCCESS'				=> 'Borttagningen av tilläggen lyckades.',
	'EXT_DELETE_ERROR'					=> 'Ingen fil har angivits eller så uppstod ett fel vid borttagningen.',
	'EXT_DELETE_NO_FILE'				=> 'Ingen fil har angivits för borttagningen.',
	'EXT_CANNOT_BE_PURGED'				=> 'Datat för det aktiva tillägget kan inte tas bort. Inaktivera tillägget för att kunna ta bort dess data.',

	'EXTENSION_ZIP_DELETE'				=> 'Radera zip-fil',
	'EXTENSION_ZIP_DELETE_CONFIRM'		=> 'Är det säkert att du vill radera zip-filen “%s”?',
	'EXTENSIONS_ZIP_DELETE_CONFIRM'		=> array(
		2	=> 'Är det säkert att du vill radera <strong>%1$s</strong> zip-filer?',
	),
	'EXT_ZIP_DELETE_SUCCESS'			=> 'Borttagningen av tilläggets zip-fil lyckades.',
	'EXT_ZIPS_DELETE_SUCCESS'			=> 'Borttagningen av tilläggens zip-filer lyckades.',
	'EXT_ZIP_DELETE_ERROR'				=> 'Ingen fil har angivits eller så uppstod ett fel vid raderingen.',

	'ACP_UPLOAD_EXT_ERROR_DEST'			=> 'Det finns ingen leverantör- eller målmapp i zip-filen. Filen sparades inte på servern.',
	'ACP_UPLOAD_EXT_ERROR_COMP'			=> '"composer.json" hittades inte i den uppladdade zip-filen. Filen sparades inte på servern.',
	'ACP_UPLOAD_EXT_ERROR_NOT_SAVED'	=> 'Filen sparades inte på servern.',
	'ACP_UPLOAD_EXT_ERROR_TRY_SELF'		=> '“Tilläggsladdaren” kan bara uppdateras med den speciella Uppdateraren eller via FTP.',
	'ACP_UPLOAD_EXT_WRONG_RESTORE'		=> 'Ett fel uppstod under uppdateringen av ett installerat tillägg. Försök uppdatera det igen.',

	'DEVELOPER'							=> 'Utvecklare',
	'DEVELOPERS'						=> 'Utvecklare',

	'EXT_UPLOAD_SAVE_ZIP'				=> 'Spara uppladdad zip-fil',
	'CHECKSUM'							=> 'Kontrollnummer',
	'RESTORE'							=> 'Återställ',
	'ZIP_UPLOADED'						=> 'Ladda upp tilläggets zip-paket',
	'EXT_ENABLE'						=> 'Aktivera',
	'EXT_ENABLE_DISABLE'				=> 'Aktivera/Inaktivera tillägget',
	'EXT_ENABLED'						=> 'Aktiveringen av tillägget lyckades.',
	'EXT_DISABLED'						=> 'Inaktiveringen av tillägget lyckades.',
	'EXT_PURGE'							=> 'Rensa tilläggets data',
	'EXT_PURGED'						=> 'Rensningen av tilläggets data lyckades.',
	'EXT_UPLOADED'						=> 'Uppladdningen lyckades.',
	'EXT_UPDATE_ENABLE'					=> 'Klicka på omställaren för att aktivera tillägget.',
	'EXT_UPDATE_CHECK_FILETREE'			=> 'Verifiera tilläggets filträd.',
	'EXT_UPDATE_ERROR'					=> 'Det blev ett fel under uppdateringen!',
	'EXT_UPDATE_TIMEOUT'				=> 'Uppdateringen pausades.',
	'EXT_UPDATES_AVAILABLE'				=> 'Uppdateringar är tillgängliga',
	'EXT_UPDATE_METHODS_TITLE'			=> 'Tillgängliga uppdateriingsmetoder',
	'EXT_UPLOAD_UPDATE_METHODS'			=> 'Du kan uppdatera tillägget med en av de tillgängliga metoderna:<ul><li><strong>Uppdatera-metoden.</strong> "Tilläggsladdaren" kan uppdateras med "Tilläggsladdarens" "Uppdaterare". Kontrollera om detta verktyg redan är tillgängligt. Om du inte har detta verktyg måste du använda den andra metoden.</li><li><strong>FTP-metoden.</strong> "Tilläggsladdaren" kan uppdateras på det ordinarie sättet. Ladda ner nya filer till din PC (klicka på knappen nedan), inaktivera tillägget i ordinarie Tilläggshanterare, kopiera de nya filerna med hjälp av ett FTP-program och aktivera tillägget i ordinarie "Hantera tillägg".</li></ul>',
	'EXT_UPDATED'						=> 'Uppdateringen lyckades.',
	'EXT_UPDATED_LATEST_VERSION'		=> 'senaste versionen är installerad',
	'EXT_SAVED_OLD_ZIP'					=> '<strong>OBS!</strong> Tilläggets tidigare version sparades i filen <strong>%s</strong> på din server. Du kan se detta i “ZIP-filshanteraren”.',
	'EXT_RESTORE_LANGUAGE'				=> '<strong>En språkkatalog saknas i den uppladdade versionen av tillägget.</strong> Du kan återställa katalogen %s från det sparade zip-arkivet för tilläggets tidigare version. Därefter kan du behöva uppdatera filerna i katalogen för att de ska vara kompatibla med tilläggets nya uppladdade version.',
	'EXT_RESTORE_LANGUAGES'				=> '<strong>Några språkkataloger saknas i den uppladdade versionen av tillägget.</strong> Du kan återställa katalogerna %1$s och %2$s från det sparade zip-arkivet för tilläggets tidigare version. Därefter kan du behöva uppdatera filerna i dessa kataloger för att de ska vara kompatibla med tilläggets nya uppladdade version.',
	'EXT_LANGUAGES_RESTORED'			=> 'Återställningen lyckades.',
	'EXT_SHOW_DESCRIPTION'				=> 'Visa beskrivningen för tillägget',
	'EXT_UPLOAD_BACK'					=> '« Tillbaka till "Tilläggsladdaren"',
	'EXT_RELOAD_PAGE'					=> 'Ladda om sidan',
	'EXT_REFRESH_PAGE'					=> 'Uppdatera sidan',
	'EXT_REFRESH_NOTICE'				=> 'Navigationsmenyn kan vara föråldrad.',

	'ERROR_COPY_FILE'					=> 'Försöket att kopiera filen “%1$s” till “%2$s” misslyckades.',
	'ERROR_CREATE_DIRECTORY'			=> 'Försöket att skapa katalogen “%s” misslyckades.',
	'ERROR_REMOVE_DIRECTORY'			=> 'Försöket att ta bort katalogen “%s” misslyckades.',
	'ERROR_CHECKSUM_MISMATCH'			=> 'Den uppladdade filens %s-hash överensstämmer inte med det tillhandahållna kontrollnumret. Filen sparades inte på servern.',
	'ERROR_ZIP_NO_COMPOSER'				=> '"composer.json" hittades inte i det begärda zip-paketet.',
	'ERROR_DIRECTORIES_NOT_RESTORED'	=> 'Återställningen kunde inte slutföras på grund av uppkomna fel.',
	'ERROR_LANGUAGE_UNKNOWN_STRUCTURE'	=> 'Strukturen i det uppladdade språkpaketet känns inte igen. Filen sparades inte på servern.',
	'ERROR_LANGUAGE_NO_EXTENSION'		=> 'Tilläggets namn är inte specificerat för språkpaketet.',
	'ERROR_LANGUAGE_NOT_DEFINED'		=> 'ISO-koden för språket måste vara definierad för att språkpaketet ska installeras korrekt. Fyll i formulärets obligatoriska fält och försök igen.',

	'ACP_UPLOAD_EXT_DIR'				=> 'Sökväg till lagringsplatsen för tilläggens zip-paket',
	'ACP_UPLOAD_EXT_DIR_EXPLAIN'		=> 'Sökväg under din phpBB-rotkatalog, t.ex. <samp>ext</samp>.<br />Du kan ändra denna sökväg för att spara zip-paket i en särskild mapp (om du till exempel vill låta användare ladda ner dessa filer, kan du ändra den till <em>downloads</em>, och om du vill förhindra sådana nerladdningar, kan du ändra den till en sökväg som ligger en nivå över http-roten för din webbplats (eller du kan skapa en mapp med en lämplig .htaccess-fil)).',

	'ACP_UPLOAD_EXT_UPDATED'			=> 'Det installerade tillägget uppdaterades.',
	'ACP_UPLOAD_EXT_UPDATED_EXPLAIN'	=> 'Du har laddat upp en zip-fil för ett tillägg som redan är installerat. Det tillägget <strong>inaktiverades automatiskt</strong> för att göra uppdateringen säkrare. <strong>Kontrollera</strong> nu om de uppladdade filerna är korrekta och <strong>aktivera</strong> tillägget om det fortfarande ska användas i forumet.',

	'ACP_UPLOAD_EXT_NO_CHECKSUM_TITLE'	=> 'Inget kontrollnummer tillhandahölls för den uppladdade filen.',
	'ACP_UPLOAD_EXT_NO_CHECKSUM'		=> '"Tilläggsladdaren" kunde inte göra en säkerhetskontroll på grund av att <strong>kontrollnumret inte tillhandahölls</strong> för den uppladdade zip-filen. Kontrollnumret används för att säkerställa att den uppladdade filen inte är skadad och/eller manipulerad.',

	'VALID_PHPBB_EXTENSIONS'			=> 'Validerade tillägg',
	'SHOW_VALID_PHPBB_EXTENSIONS'		=> 'Visa validerade tillägg',
	'VALID_PHPBB_EXTENSIONS_TITLE'		=> 'Du kan ladda ner validerade tillägg från CDB:n på phpbb.com eller kolla på deras hemsidor.',
	'VALID_PHPBB_EXTENSIONS_EMPTY_LIST'	=> 'Inga tillägg är föreslagna för tillfället. Kontrollera om det finns någon uppdatering för "Tilläggsladdaren".',
	'POSSIBLE_SOLUTIONS'				=> 'Möjliga lösningar',

	'ACP_UPLOAD_EXT_MANAGER_EXPLAIN'	=> 'Tilläggshanteraren i "Tilläggsladdaren" är ett verktyg i ditt phpBB Forum som ger dig möjlighet att hantera all dina tillägg och visa information om dem.',
	'ACP_UPLOAD_ZIP_TITLE'				=> 'ZIP-filshanteraren',
	'ACP_UPLOAD_UNINSTALLED_TITLE'		=> 'Ta bort tillägg',

	'EXT_DETAILS_README'				=> 'Läsmig',
	'EXT_DETAILS_CHANGELOG'				=> 'Ändringslogg',
	'EXT_DETAILS_LANGUAGES'				=> 'Språk',
	'EXT_DETAILS_FILETREE'				=> 'Filträd',
	'EXT_DETAILS_TOOLS'					=> 'Verktyg',

	'DEFAULT'							=> 'standard',
	'EXT_LANGUAGE_ISO_CODE'				=> 'ISO-kod',
	'EXT_LANGUAGES'						=> 'Uppladdade språkpaket',
	'EXT_LANGUAGES_UPLOAD'				=> 'Ladda upp ett språkpaket',
	'EXT_LANGUAGES_UPLOAD_EXPLAIN'		=> 'Här kan du ladda upp ett zippat paket med de nödvändiga språkfilerna för detta tillägg från din lokala dator eller en fjärrserver. “Tilläggsladdaren” kommer att därefter försöka zippa upp filerna och flytta dem till rätt plats.<br />Välj en fil eller skriv en länk i fälten nedan.<br />Glöm inte att specificera språkets ISO-kod i motsvarande fält nedan (exempel: <strong>en</strong>).<br /><strong>VIKTIGT!</strong> Det nuvarande språktilläggets katalog med den ISO-koden kommer att raderas om den existerar, <strong>inget zip-arkiv kommer att skapas för den</strong>.',
	'EXT_LANGUAGE_UPLOADED'				=> 'Uppladdningen av språkpaketet “%s” lyckades.',
	'EXT_LANGUAGE_DELETE_CONFIRM'		=> 'Är det säkert att du vill ta bort språkpaketet “%s”?',
	'EXT_LANGUAGES_DELETE_CONFIRM'		=> array(
		2	=> 'Är det säkert att du vill ta bort språkpaketen <strong>%1$s</strong>?',
	),
	'EXT_LANGUAGE_DELETE_SUCCESS'		=> 'Borttagningen av tilläggets språkpaket lyckades.',
	'EXT_LANGUAGES_DELETE_SUCCESS'		=> 'Borttagningen av tilläggets språkpaket lyckades.',
	'EXT_LANGUAGE_DELETE_ERROR'			=> 'Ingen fil har agnivits eller så uppstod ett fel under borttagningen.',

	'EXT_TOOLS_DOWNLOAD_TITLE'			=> 'Ladda ner tilläggspaket',
	'EXT_TOOLS_DOWNLOAD'				=> 'Du kan ladda ner en korrekt paketerad zip-fil för tillägget till din PC. Du kan även välja att ta bort suffixet för utvecklarversionen (t.ex. för att korta tiden att förbereda tillägget för CDB:n).',
	'EXT_TOOLS_DOWNLOAD_DELETE_SUFFIX'	=> 'Ta bort utvecklarsuffixet om det existerar',
	'EXT_DOWNLOAD_ERROR'				=> 'Försöket att ladda ner tillägget “%s” misslyckades.',

	'EXT_LOAD_ERROR'					=> 'Laddningen misslyckades',
	'EXT_LOAD_TIMEOUT'					=> 'Laddningen pausades',
	'EXT_LOAD_ERROR_EXPLAIN'			=> 'Ett fel uppstod under laddningen.',
	'EXT_LOAD_ERROR_SHOW'				=> 'Visa de uppkomna felen',
	'EXT_LOAD_SOLUTIONS'				=> 'Kontrollera felloggsfilen på din server, eliminera problemet och försök igen.',

	'UPLOAD_DESCRIPTION_UPLOAD'			=> 'Ladda upp phpBB-tillägg',
	'UPLOAD_DESCRIPTION_UPLOAD_CDB'		=> 'CDB på phpbb.com',
	'UPLOAD_DESCRIPTION_UPLOAD_LOCAL'	=> 'Lokal PC',
	'UPLOAD_DESCRIPTION_UPLOAD_REMOTE'	=> 'Fjärrserver',
	'UPLOAD_DESCRIPTION_UPDATE'			=> 'Uppdatera phpBB-tillägg',
	'UPLOAD_DESCRIPTION_UPDATE_ABOUT'	=> 'Du kan uppdatera alla tidigare uppladdade tillägg. Det tillägg du vill uppdatera kommer att inaktiveras automatiskt så att varje uppdatering sker säkert.',
	'UPLOAD_DESCRIPTION_MANAGE'			=> 'Hantera phpBB-tillägg',
	'UPLOAD_DESCRIPTION_MANAGE_ACTIONS'	=> 'Installera/avinstallera valfritt tillägg',
	'UPLOAD_DESCRIPTION_MANAGE_LANG'	=> 'Ladda upp och hantera tilläggens språkpaket',
	'UPLOAD_DESCRIPTION_MANAGE_DETAILS'	=> 'Visa informationen och filträd',
	'UPLOAD_DESCRIPTION_DESIGN'			=> 'Interaktivt gränssnitt',
	'UPLOAD_DESCRIPTION_DESIGN_ABOUT'	=> 'Du kan utföra åtgärder snabbare tack vare JavaScript-funktioner. Färgmeddelanden och verktygstips kommer att hjälpa dig fatta rätt beslut.',
	'UPLOAD_DESCRIPTION_ZIP'			=> 'ZIP-filshanteraren',
	'UPLOAD_DESCRIPTION_ZIP_SAVE'		=> 'Spara zip-filer i den katalog du själv väljer',
	'UPLOAD_DESCRIPTION_ZIP_UNPACK'		=> 'Packa upp en zip-fil för att installera ett tillägg',
	'UPLOAD_DESCRIPTION_ZIP_DOWNLOAD'	=> 'Ladda ner korrekta zip-paket för tillägg',
	'UPLOAD_DESCRIPTION_CLEANER'		=> '"Tilläggsstädaren"',
	'UPLOAD_DESCRIPTION_CLEANER_ABOUT'	=> 'Du kan ta bort kataloger eller zip-filer för tillägg från servern.',
));
