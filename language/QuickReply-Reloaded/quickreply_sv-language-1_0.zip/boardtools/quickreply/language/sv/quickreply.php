<?php
/**
 *
 * @package       QuickReply Reloaded
 * @copyright (c) 2014 - 2016 Tatiana5 and LavIgor
 * @license       http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 * @translated    Tage Strandell (Webmaster - http://www.vulcanriders-sweden.org)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'QR_BBPOST'                        => 'Inläggets källa',
	'QR_INSERT_TEXT'                   => 'Lägg in ett citat i “Snabbsvarsformuläret”',
	'QR_PROFILE'                       => 'Gå till profil',
	'QR_QUICKNICK'                     => 'Användarnamnsreferens',
	'QR_QUICKNICK_TITLE'               => 'Lägg in användarnamn i “Snabbsvarsformuläret”',
	'QR_REPLY_IN_PM'                   => 'Svara med PM',
	//begin mod Translit
	'QR_TRANSLIT_TEXT'                 => 'Översätt:',
	'QR_TRANSLIT_TEXT_TO_RU'           => 'till Ryska',
	'QR_TRANSLIT_TEXT_TOOLTIP'         => 'Klicka på knappen för att direkt visa på Ryska',
	//end mod Translit
	//begin mod CapsLock Transform
	'QR_TRANSFORM_TEXT'                => 'Växla typform:',
	'QR_TRANSFORM_TEXT_TOOLTIP'        => 'Tryck ner valfri knappp för att växla typform på markerad text',
	'QR_TRANSFORM_TEXT_LOWER'          => '&#9660; abc',
	'QR_TRANSFORM_TEXT_UPPER'          => '&#9650; ABC',
	'QR_TRANSFORM_TEXT_INVERS'         => '&#9660;&#9650; aBC',
	'QR_TRANSFORM_TEXT_LOWER_TOOLTIP'  => 'små bokstäver',
	'QR_TRANSFORM_TEXT_UPPER_TOOLTIP'  => 'STORA BOKSTÄVER',
	'QR_TRANSFORM_TEXT_INVERS_TOOLTIP' => 'iNVERTERAD tYPFORM',
	//end mod CapsLock Transform
));
