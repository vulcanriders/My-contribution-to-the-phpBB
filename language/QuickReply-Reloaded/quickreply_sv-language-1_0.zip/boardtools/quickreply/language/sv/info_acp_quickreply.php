<?php
/**
 *
 * @package       QuickReply Reloaded
 * @copyright (c) 2014 - 2016 Tatiana5 and LavIgor
 * @license       http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 * @translated    Tage Strandell (Webmaster - http://www.vulcanriders-sweden.org)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_QUICKREPLY'                  => 'Snabbsvar',
	'ACP_QUICKREPLY_EXPLAIN'          => 'Snabbsvar - Inställningar',
	//
	'ACP_QR_AJAX_PAGINATION'          => 'Tillåt ämnesnavigering utan att ladda om sidan',
	'ACP_QR_AJAX_PAGINATION_EXPLAIN'  => 'Tillåt användaren att aktivera inställningen: “Uppdatera inte snabbsvarsformuläret vid navigering inom ämnet”.',
	'ACP_QR_AJAX_SUBMIT'              => 'Aktivera Ajax-funktionen för “Skicka”',
	'ACP_QR_AJAX_SUBMIT_EXPLAIN'      => 'Tillåt att meddelanden skickas utan att sidan uppdateras.',
	'ACP_QR_ALLOW_FOR_GUESTS'         => 'Snabbsvar är aktiverat för gäster',
	'ACP_QR_ATTACH'                   => 'Tillåt bilagor',
	'ACP_QR_BBCODE'                   => 'Aktivera BBcode',
	'ACP_QR_BBCODE_EXPLAIN'           => 'Lägg till BBCode-knappar i “Snabbsvarsformuläret”.',
	'ACP_QR_CAPSLOCK'                 => 'Aktivera ändra text till stora/små bokstäver',
	'ACP_QR_COLOUR_NICKNAME'          => 'Lägg till färg vid “Användarnamnsreferens”',
	'ACP_QR_COMMA'                    => 'Lägg till komma efter användarnamn',
	'ACP_QR_COMMA_EXPLAIN'            => 'Lägg automatiskt till komma efter användarnamnet när “Användarnamnsreferens” används.',
	'ACP_QR_CTRLENTER'                => 'Aktivera “Ctrl+Enter” för “Skicka”',
	'ACP_QR_CTRLENTER_EXPLAIN'        => 'Tillåt att meddelanden skickas genom att använda “Ctrl+Enter”.',
	'ACP_QR_ENABLE_RE'                => 'Aktivera “Re:”',
	'ACP_QR_ENABLE_RE_EXPLAIN'        => 'Prefixet “Re:” läggs automatiskt till i “Ämnesrubrik” i “Snabbsvarsformuläret”.',
	'ACP_QR_FULL_QUOTE'               => 'Lägg in fullständiga citat i “Snabbsvarsformuläret”',
	'ACP_QR_FULL_QUOTE_EXPLAIN'       => 'Ersätter standardfunktionen för knappen “Svara med citat”.',
	'ACP_QR_HIDE_SUBJECT_BOX'         => 'Dölj ämnesrubriksfältet när möjligheten att ändra ämnesrubriken är avstängd',
	'ACP_QR_HIDE_SUBJECT_BOX_EXPLAIN' => 'Om användaren inte har behörighet att ändra inläggsrubriken kommer formulärfältet för rubriken att döljas istället för att låsas.',
	'ACP_QR_QUICKNICK'                => 'Lägg till Användarnamn',
	'ACP_QR_QUICKNICK_EXPLAIN'        => 'Tillåt att användarnamnet läggs till i snabbsvaret när länken “Användarnamnsreferens”.',
	'ACP_QR_QUICKNICK_PM'             => 'Inkludera knappen «Svara med PM» i rullgardinsmenyn för funktionen “Användarnamnsreferens”',
	'ACP_QR_QUICKNICK_REF'            => 'Aktivera special-tag för användarreferens',
	'ACP_QR_QUICKNICK_REF_EXPLAIN'    => 'BBCodeen [ref] kommer att användas istället för [b] i för funktionen “Användarnamnsreferens”.',
	'ACP_QR_QUICKQUOTE'               => 'Aktivera snabbcitat',
	'ACP_QR_QUICKQUOTE_EXPLAIN'       => 'Tillåt citat genom ett “popup-fönster” som visas när en text i ett meddelande markeras.',
	'ACP_QR_QUICKQUOTE_LINK'          => 'Lägg till en länk till inläggsförfattarens profil när snabbcitat används',
	'ACP_QR_SCROLL_TIME'              => 'Tid för en enskild skroll- och animeringshändelse',
	'ACP_QR_SCROLL_TIME_EXPLAIN'      => 'Tid i millisekunder för den mjuka skrollningsfunktionen. Ange 0 för att använda standardskrollning.',
	'ACP_QR_SHOW_BUTTON_TRANSLIT'     => 'Visa knappen “Förnya”',
	'ACP_QR_SHOW_SUBJECTS'            => 'Visa inläggsrubriker i ämnen',
	'ACP_QR_SHOW_SUBJECTS_IN_SEARCH'  => 'Visa inläggsrubriker i sökresultaten',
	'ACP_QR_SMILIES'                  => 'Aktivera Smilies',
	'ACP_QR_SMILIES_EXPLAIN'          => 'Tillåt visningen av smiles i “Snabbsvarsformuläret”.',
	'ACP_QR_SOURCE_POST'              => 'Lägg till enlänk det citerade meddelandet',
));
