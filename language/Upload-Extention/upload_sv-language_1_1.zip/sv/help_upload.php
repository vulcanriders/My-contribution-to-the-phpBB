<?php
/**
*
* @package Upload Extensions
* @copyright (c) 2014 - 2015 Igor Lavrov (https://github.com/LavIgor) and John Peskens (http://ForumHulp.com)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
* @translated Tage Strandell (Webmaster - http://www.vulcanriders-sweden.org) v1.1
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

// Några tecken du kan kopiera och klistra in:
// ’ » “ ” …

$help = array(
	array(
		0 => '--',
		1 => 'Generella moduler'
	),
	array(
		0 => 'Vad kan jag göra med funktionen “Ladda upp tillägg”?',
		1 => 'Du kan ladda upp tillägg från olika källor utan att tvingas använda ett FTP-program. Om du laddar upp ett tillägg som redan finns i ditt forum kommer det att uppdateras och den gamla versionen sparas automatiskt i den angivna katalogen i forumet - se vidare modulen "ZIP-filshantering”. Du kan även spara en zip-fil med den senast uppladdade versionen av tillägget - bocka i kryssrutan “Spara uppladdad zip-fil” innan uppladdningen startas. Du kan försäkra dig om att du laddar upp det äkta zip-paketet för tillägg om du anger dess kontrollnummer i motsvarande formulärfält.'
	),
	array(
		0 => 'Vad är skillnaden mellan “Tilläggshanteraren” i “Tilläggsladdaren” och den ordinarie “Hantera tillägg”?',
		1 => 'Precis som ordinarie “Hantera tillägg” är “Tilläggshanteraren” i “Tilläggsladdaren” ett verktyg i ditt forum som ger dig möjlighet att hantera alla dina tillägg och visa information om dem. Men den kan ses som en “uppgraderad version” av standardmodulen.<br /><br /><strong>Viktigaste fördelarna:</strong><ul><li>Alla uppladdade tillägg sorteras i alfabetisk ordning, oavsett om de är aktiverade, inaktiverade eller oinstallerade. Undantag: skadade tillägg.</li><li>Skadade tillägg visas separat på samma sida i “Tilläggshanteraren” under listan av normalt fungerande tillägg. För varje skadat tillägg beskrivs orsaken till att de är otillgänga. Specifika varningar är tillagda till dessa beskrivningar när det skadade tillägget är installerat eller har viss data sparad i din databas. Du kan klicka på raden för varje skadat tillägg och se informationen precis på samma sätt som för övriga tillägg.</li><li>Varje tillägg (om det inte är ett skadat) kan aktiveras med ett enkelt klick på statusväxlaren som finns till vänster om dess namn i listan.</li></ul>'
	),
	array(
		0 => 'Varför behöver jag modulen “ZIP-filshantering”?',
		1 => 'Ibland kan du upptäcka att det är bra att kunna spara dina tillägg i ett arkiv eller att kunna dela dem med andra. Arkiven kan vara gamla versioner av uppladdade tillägg (som av datasäkerhetsskkäl packas automatiskt), varje paket du valt att spara genom att bocka i kryssrutan “Spara uppladdad zip-fil” innan en uppladdning startas eller varje zip-fil för tillägg som är sparad i den särskilda katalogen (se frågan “Var kan jag ange vilken katalog som ska användas för att spara zip-filer för tillägg?” nedan). Du kan packa upp, ladda ner och radera dessa paket.'
	),
	array(
		0 => 'Hur kan jag använda modulen “Ta bort tillägg”?',
		1 => 'Med modulen “Ta bort tillägg” kan du ta bort filerna till o-/avinstallerade tillägg från din server, så att du kan genomföra en fullständig avinstallation utan att använda ett FTP-program. När du inte behöver ett tillägg längre, kan du ta bort det helt och hållet från ditt forum. För att göra det behöver du utföra följande steg:<ul><li>Försäkra dig först om att du inte längre behöver ett specifikt tillägg. Innan du påbörjar borttagning rekommenderar vi att du säkerhetskopierar filerna och databasen.</li><li>Gå sedan till “Tilläggshanteraren” i “Tilläggsladdaren”, sök rätt på tillägget du vill ta bort för att kontrollera att det är inaktiverat: Klicka på statusväxlaren vid tillägget <em>om statusväxlaren är grön</em>.</li><li>Kontrollera att tilläggets data är raderade: <em>om papperskorgsknappen visas</em>, klicka på den och bekräfta åtgärden.</li><li>Gå därefter till modulen “Ta bort tillägg”, klicka på länken “Ta bort tillägg” på raden för tillägget och bekräfta åtgärden.</li></ul>'
	),
	array(
		0 => '--',
		1 => 'Uppladdningsprocessen'
	),
	array(
		0 => 'Hur gör jag för att ladda upp validerade tillägg från CDB:n på phpbb.com?',
		1 => 'Klicka på länken “Visa validerade tillägg” på “Tilläggsladdarens” förstasida. Välj det tillägg du vill ladda upp och klicka på knappen “Ladda ner” på tilläggsraden. Notera ordleken här: tillägget blir <em>nerladdat</em> från den externa källan och <em>uppladdat</em> till din server.'
	),
	array(
		0 => 'Hur laddar jag upp från andra externa källor?',
		1 => 'Kopiera <strong>direktlänken</strong> till tilläggets zip-paket (om länken inte är från webbplatsen phpbb.com, måste den ha filändelsen <code>.zip</code>) till det avsedda formulärfältet “Ladda upp tillägg” och klicka på knappen “Ladda upp”.'
	),
	array(
		0 => 'Hur laddar jag upp ett tillägg från min lokala PC?',
		1 => 'För att göra det klickar du på knappen “Välj...” i formuläret “Ladda upp tillägg”, välj sedan tilläggets zip-fil på din dator, klicka sedan på knappen “Ladda upp”.'
	),
	array(
		0 => 'Jag har kopierat länken för tilläggets zip-fil till fältet och klickat på knappen “Ladda upp” men jag får ett felmeddelande. Vad är det för fel på länken?',
		1 => 'För att kunna ladda upp tillägget måste du säkerställa att följande villkor är uppfyllda:<ol><li>Det måste vara en <strong>direktlänk</strong>: för uppladdningar från andra källor än phpbb.com måste den ha filändelsen <code>.zip</code>.</li><li> Länken måste leda till tilläggets <strong>zip-fil</strong>, inte till dess beskrivningssida.</li></ol>'
	),
	array(
		0 => 'Vad är kontrollnummer? Vart hittar jag det?',
		1 => 'Kontrollnummer används för att verifiera äktheten hos den uppladdade filen. Det kontrolleras för att säkerställa att filen på fjärrservern och den fil som laddas upp till din server är desamma. Kontrollnumret kan normalt erhållas från platsen där originalfilen ligger.'
	),
	array(
		0 => '--',
		1 => '“Tilläggshanteraren” i “Tilläggsladdaren”'
	),
	array(
		0 => 'Hur används “Tilläggshanteraren” i “Tilläggsladdaren”?',
		1 => 'Statusen för varje tillägg visas som en statusväxlarknapp.<ul><li>En grön statusväxlare betyder att tillägget är aktivt. Om du klickar på en grön statusväxlare kommer tillägget att bli <strong>inaktiverat</strong>.</li><li>En röd statusväxlare betyder att tillägget är inaktiverat. När du klickar på en röd statusväxlare kommer tillägget att bli <strong>aktiverat</strong>.</li><li>Om tillägget är inaktiverat, röd statusväxlare, men har viss data sparad i databasen kan du radera datat genom att klicka på papperskorgen intill statusväxlaren.<br /><em>Att klicka på papperskorgen avinstallerar tillägget från databasen. Vill du ta bort tilläggets filer från servern måste du använda verktyget “Tilläggsstädaren”.</em></li></ul><br />Du kan också kontrollera alla tilläggs versioner igen genom att klicka på motsvarande länk eller ställa in versionskontrollen precis som i ordinarie “Hantera tillägg”.'
	),
	array(
		0 => 'Hur är det med skadade tillägg? Kan jag avinstallera dem?',
		1 => 'Ja naturligtvis! Skadade tillägg visas i “Tilläggshanteraren” i “Tilläggsladdaren” nedanför listan med normalt fungerande tillägg. Du kan se orsaken till varför dessa tillägg är skadade och om de har några data sparade i din databas. Klicka på en rad med ett skadat tillägg för att visa informationen om hur du hanterar detta.'
	),
	array(
		0 => 'Statusväxlaren för ett tillägg är grå. Varför?',
		1 => 'Den grå statusväxlaren betyder att du, för närvarande, inte kan göra något med det tillägget. Förmodligen pågår en annan åtgärd för tillfället. Dessutom kan inte “Tilläggsladdaren” inaktivera sig själv - det är orsaken till att dess statusväxlare också är grå.'
	),
	array(
		0 => '--',
		1 => 'Tilläggets informationssida'
	),
	array(
		0 => 'Vilken information visas för mina tillägg?',
		1 => 'Vilken information som visas beror på ett antal faktorer.<ul><li>Den generella beskrivningen tillhandahålls av tilläggets utvecklare i filen <code>composer.json</code> (liksom varningar om tillägget är skadat).</li><li>Tilläggets versionsnummer (om det inte är skadat).</li><li>Innehållet i filen <code>README.md</code> (om den finns i tilläggets katalog).</li><li>Innehållet i filen <code>CHANGELOG.md</code> (om den finns i tilläggets katalog).</li><li>Tilläggets uppladdade språkpaket.</li><li>Tilläggets filträd och filernas innehåll.</li></ul>'
	),
	array(
		0 => 'Vad kan jag göra med tillägget på informationssidan?',
		1 => 'Du kan:<ul><li>Aktivera tillägget om dess statusväxlare är röd.</li><li>Inaktivera tillägget om dess statusväxlare är grön.</li><li>Radera tilläggets data från databasen om den röda papperskorgsknappen visas.</li><li>Kontrollera tilläggets senaste version om tilläggets utvecklare tillhandahållit länken till versionskontrollfilen. Om tilläggets version visas i en grön bubbla - den senaste versionen av tillägget är installerad. Om bubblan är röd - en nyare version av tillägget finns tillgänglig. I annat fall - ingen versionskontrollen kan utföras.</li><li>Ta emot en uppdatering om du ser ett kugghjul intill tilläggets versionsbubbla. Klicka på kugghjulet: om knappen “Uppdatera” visas - Klicka på den, bekräfta och “Tilläggsladdaren” uppdaterar ditt tillägg. Du kan även se lanseringsmeddelanden genom att klicka på motsvarande knapp om tilläggets utvecklare tillhandahållit den länken. <strong>OBS!</strong> Om du avaktiverat JavaScript i din webbläsare, kommer dessa knappar vara placerade i sektionen för tilläggets informationen.</li><li>Hantera tilläggets språkpaket. Du kan ladda upp nya språk till tillägget - se frågan “Vilka språkpaket kan jag ladda upp till ett tillägg?” nedan. Du kan även ta bort redan installerade språkpaket.</li><li>Ladda ner tilläggspaketet (se frågan “Vad är syftet med funktionen “Ladda ner paketerat tillägg”?” nedan).</li></ul>'
	),
	array(
		0 => 'Vilka språkpaket kan jag ladda upp till ett tillägg?',
		1 => 'Du kan ladda upp alla zip-paket som innehåller språkfiler till tillägget om de har någon av följande strukturer:<ul><li><code>ZIP_FILE_ROOT/language_files</code>, or</li><li><code>ZIP_FILE_ROOT/single_directory/language_files</code>, or</li><li><code>ZIP_FILE_ROOT/single_directory/language_ISO_code/language_files</code>.</li></ul><br />För ytterligare information om uppladdningsprocessen läs sektionen “Uppladdningsprocess” ovan.'
	),
	array(
		0 => 'Vad är syftet med funktionen “Ladda ner paketerat tillägg”?',
		1 => '“Tilläggsladdaren” ger dig möjligheten att ladda ner fullständiga zip-paket för varje uppladdat tillägg i ditt forum till din lokala PC. Du kan även bocka i en kryssruta för att ta bort suffixet för utvecklingsversionen - detta kan hjälpa dig att korta tiden att förbereda tillägget för CDB:n. Gå till tilläggets informationssida och klicka på knappen till sektionen “Verktyg”. Knappen “Ladda ner” kommer då att visas.'
	),
	array(
		0 => '--',
		1 => 'ZIP-filshanteraren'
	),
	array(
		0 => 'Var kan jag ange vilken katalog som ska användas för att spara zip-filer för tillägg?',
		1 => 'I din Kontrollpanel går du till <code>Allmänt -> Serverkonfiguration -> Serverinställningar -> Sökvägsinställningar -> Sökväg till lagringsplatsen för tilläggens zip-paket</code>.'
	),
	array(
		0 => 'Hur kan jag ta bort zip-paketen för flera tillägg samtidigt?',
		1 => 'Först av allt bör du tänka efter om du verkligen måste göra en sådan åtgärd; Vi rekommenderar att du först gör erforderliga backupper. Gå sedan till modulen “ZIP-filshanteraren”, markera kryssrutan på raden för de zip-paket du vill ta bort, klicka på knappen “Ta bort markerat” och bekräfta åtgärden.'
	),
	array(
		0 => '--',
		1 => 'Tilläggsstädaren'
	),
	array(
		0 => 'Vad är “Tilläggsstädaren”?',
		1 => '“Tilläggsstädaren” är det namn på modulen “Ta bort tillägg” i “Tilläggsladdaren” som ibland används i dokumentationen.'
	),
	array(
		0 => 'Ett tillägg är installerat i mitt forum men jag kan inte ta bort det. Varför?',
		1 => 'Det tillägg du vill ta bort måste vara inaktiverat och dess data måste vara raderat i databasen innan du använder “Tilläggsstädaren”. Se frågan “Hur kan jag använda modulen “Ta bort tillägg”?” ovan.'
	),
	array(
		0 => 'Hur kan jag ta bort flera tillägg samtidigt?',
		1 => 'Först av allt bör du tänka efter om du verkligen måste göra en sådan åtgärd; Vi rekommenderar att du först gör erforderliga backupper. Gå sedan till modulen “Ta bort tillägg”, markera kryssrutan på raden för de tillägg du vill ta bort, klicka på knappen “Ta bort markerat” och bekräfta åtgärden. <strong>Dessa tillägg kommer inta att sparas som zip-filer! Deras kataloger kommer helt att tas bort från servern.</strong>'
	),
	array(
		0 => '--',
		1 => 'Interaktivt gränssnitt'
	),
	array(
		0 => 'Vilka är fördelarna med JavaScript-funktionaliteten?',
		1 => 'Sidor laddas snabbare, designelement ändras snabbt när du använder dem, verktygstips visas för att hjälpa dig. Alla dessa funktioner sparar tid och är endast tillgängliga om du aktiverat JavaScript i din webbläsare.'
	),
);
